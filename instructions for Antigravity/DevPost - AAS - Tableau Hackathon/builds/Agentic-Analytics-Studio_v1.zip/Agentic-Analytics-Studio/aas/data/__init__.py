"""Sample datasets used by the Agentic Analytics Studio skeleton."""

__all__ = []